Analyze these evaluation runs for claude-code using tmux on python-repl.

The runs are located in evaluation-results/ with filenames:
evaluation-results/claude-code--python-repl--tmux--20250815222829047000-prompt.md
evaluation-results/claude-code--python-repl--tmux--20250815222829047000-scrollbuffer.txt
evaluation-results/claude-code--python-repl--tmux--20250815223044521001-prompt.md
evaluation-results/claude-code--python-repl--tmux--20250815223044521001-scrollbuffer.txt
evaluation-results/claude-code--python-repl--tmux--20250815223224978002-prompt.md
evaluation-results/claude-code--python-repl--tmux--20250815223224978002-scrollbuffer.txt
evaluation-results/claude-code--python-repl--tmux--20250815223405440003-prompt.md
evaluation-results/claude-code--python-repl--tmux--20250815223405440003-scrollbuffer.txt
evaluation-results/claude-code--python-repl--tmux--20250815223655943004-prompt.md
evaluation-results/claude-code--python-repl--tmux--20250815223655943004-scrollbuffer.txt
evaluation-results/claude-code--python-repl--tmux--20250815223931433005-prompt.md
evaluation-results/claude-code--python-repl--tmux--20250815223931433005-scrollbuffer.txt
evaluation-results/claude-code--python-repl--tmux--20250815224156914006-prompt.md
evaluation-results/claude-code--python-repl--tmux--20250815224156914006-scrollbuffer.txt
evaluation-results/claude-code--python-repl--tmux--20250815224422445007-prompt.md
evaluation-results/claude-code--python-repl--tmux--20250815224422445007-scrollbuffer.txt
evaluation-results/claude-code--python-repl--tmux--20250815224657970008-prompt.md
evaluation-results/claude-code--python-repl--tmux--20250815224657970008-scrollbuffer.txt
evaluation-results/claude-code--python-repl--tmux--20250815224943508009-prompt.md
evaluation-results/claude-code--python-repl--tmux--20250815224943508009-scrollbuffer.txt

IMPORTANT: You MUST read EVERY file listed above IN FULL. It is considered a failure if you do not read each file completely. Do not skim or summarize - read the entire content of each file.

After reading ALL files completely, provide your assessment using EXACTLY this format:

## Overall Performance
[Your summary of how well the agent performed across all runs]

## What Went Well
- [Strength 1]
- [Strength 2]
- [Additional strengths as bullet points]

## What Went Wrong
- [Issue 1]
- [Issue 2]
- [Additional issues as bullet points]

## Run-by-Run Analysis
- Run 20250815222829047000: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815223044521001: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815223224978002: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815223405440003: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815223655943004: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815223931433005: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815224156914006: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815224422445007: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815224657970008: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815224943508009: [Pass/Fail] - [1-2 sentence assessment]

## Recommendations
[Your key improvements that would help the agent perform better]

DO NOT deviate from this format. DO NOT add additional sections. DO NOT skip any sections.