Analyze these evaluation runs for claude-code using terminalcp-cli on python-repl.

The runs are located in evaluation-results/ with filenames:
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815232035526000-prompt.md
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815232035526000-scrollbuffer.txt
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815232216503001-prompt.md
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815232216503001-scrollbuffer.txt
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815232502499002-prompt.md
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815232502499002-scrollbuffer.txt
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815232713454003-prompt.md
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815232713454003-scrollbuffer.txt
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815233014466004-prompt.md
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815233014466004-scrollbuffer.txt
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815233300444005-prompt.md
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815233300444005-scrollbuffer.txt
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815233541438006-prompt.md
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815233541438006-scrollbuffer.txt
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815233822432007-prompt.md
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815233822432007-scrollbuffer.txt
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815234048422008-prompt.md
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815234048422008-scrollbuffer.txt
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815234334413009-prompt.md
evaluation-results/claude-code--python-repl--terminalcp-cli--20250815234334413009-scrollbuffer.txt

IMPORTANT: You MUST read EVERY file listed above IN FULL. It is considered a failure if you do not read each file completely. Do not skim or summarize - read the entire content of each file.

After reading ALL files completely, provide your assessment using EXACTLY this format:

## Overall Performance
[Your summary of how well the agent performed across all runs]

## What Went Well
- [Strength 1]
- [Strength 2]
- [Additional strengths as bullet points]

## What Went Wrong
- [Issue 1]
- [Issue 2]
- [Additional issues as bullet points]

## Run-by-Run Analysis
- Run 20250815232035526000: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815232216503001: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815232502499002: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815232713454003: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815233014466004: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815233300444005: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815233541438006: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815233822432007: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815234048422008: [Pass/Fail] - [1-2 sentence assessment]
- Run 20250815234334413009: [Pass/Fail] - [1-2 sentence assessment]

## Recommendations
[Your key improvements that would help the agent perform better]

DO NOT deviate from this format. DO NOT add additional sections. DO NOT skip any sections.